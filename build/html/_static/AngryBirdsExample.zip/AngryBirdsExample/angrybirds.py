# This is a pygame application and sample classes for
# the organization of a pygame application.

import pygame

class RedBird(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()
        self.image = pygame.image.load("images/smallredbird.png")
        self.rect = self.image.get_rect()
        self.originalImage = self.image
        self.rect.x = x
        self.rect.y = y
        self.dx = 0
        self.dy = 0
        self.vecx = 20
        self.vecy = 0
        self.angle = 0
        self.rotateAlpha = 0

    def getX(self):
        return self.rect.x

    def getY(self):
        return self.rect.y

    def moveLeft(self):
        self.rect.x = self.rect.x - 1
        self.vecx += 1

    def moveDown(self):
        self.rect.y = self.rect.y + 1
        self.vecy -= 1

    def launch(self):
        self.dx = self.vecx/5
        self.dy = self.vecy/5
        self.rotateAlpha = 2

    def move(self):
        self.rect.x += self.dx
        self.rect.y += self.dy
        self.rotate(self.rotateAlpha)

    def rotate(self,angle):
        self.angle += angle
        self.angle = self.angle % 360
        self.image = pygame.transform.rotate(self.originalImage, self.angle)
        self.rect = self.image.get_rect(center=self.rect.center)

class SlingShotFG(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()
        self.image = pygame.image.load("images/slingshotfg.png")
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class SlingShotBG(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()
        self.image = pygame.image.load("images/slingshotbg.png")
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class RubberBand:
    def __init__(self):
        self.rect = None
        self.count = 0

    def draw(self,screen,x1,y1,x2,y2):
        if self.count < 5:
            self.rect = pygame.draw.polygon(screen,(49,24,10),[(x1,y1),(x2,y2),(190,477),(192, 462)])


    def clear(self,screen):
        #self.count+=1
        if self.rect != None:
            pygame.display.update(self.rect)




class App:
    def __init__(self):
        self.running = True
        self.screen = None
        self.size = self.width, self.height = 1100, 727
        self.rubberBand = RubberBand()

    def on_init(self):
        # The following lines are needed for any pygame.
        pygame.init()
        self.screen = pygame.display.set_mode(self.size, pygame.HWSURFACE | pygame.DOUBLEBUF)
        self.bombExploding = pygame.mixer.Sound("Bomb_Exploding-Sound_Explorer-68256487.wav")
        self.running = True

        # This loads the background image into the screen and sets the title bar
        self.bgImg = pygame.image.load("images/angrybirdsbg3.png")
        self.screen.blit(self.bgImg,(0,0))
        pygame.display.set_caption("Angry Birds")

        # self.sprites is a RenderUpdates group. A group is a group of sprites. Groups
        # provide the ability to draw sprites on the screen and other management of
        # sprites.
        self.sprites = pygame.sprite.RenderUpdates()
        self.behind = pygame.sprite.RenderUpdates()
        self.infront = pygame.sprite.RenderUpdates()

        # The bird is one of the sprites. The self.birds list is the list of available
        # birds for flying. The birds are all added to the self.sprites group.
        bird = RedBird(50,520)
        self.birds = [bird]
        self.sprites.add(bird)

        self.slingshotfg = SlingShotFG(190,450)
        self.slingshotbg = SlingShotBG(190,450)

        self.behind.add(self.slingshotbg)
        self.infront.add(self.slingshotfg)

        # This will be the current bird which we will get from the self.birds list.
        self.bird = None
        return True


    def on_event(self, event):
        def loadBird():
            if self.bird == None:
                self.bird = self.birds.pop(0)
                self.bird.rect.x = 140
                self.bird.rect.y = 450

        def launchBird():
            self.bombExploding.play()
            self.bird.launch()

        if event.type == pygame.QUIT:
            self.running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT or event.key == 'a':
                loadBird()
                self.bird.moveLeft()
            elif event.key == pygame.K_DOWN or event.key == 'z':
                loadBird()
                self.bird.moveDown()
            elif event.key == pygame.K_SPACE:
                launchBird()

    def on_loop(self):
        if self.bird != None:
            self.bird.move()

    def on_render(self):
        # These next lines clear each sprite from the screen by redrawing
        # the background behind that sprite.
        self.infront.clear(self.screen,self.bgImg)
        self.sprites.clear(self.screen,self.bgImg)
        self.behind.clear(self.screen,self.bgImg)
        self.rubberBand.clear(self.screen)

        # These next lines call blit to draw each sprite on the screen in
        # each group of sprites.
        self.behind.draw(self.screen)
        self.sprites.draw(self.screen)
        self.infront.draw(self.screen)


        if self.bird != None:
            self.rubberBand.draw(self.screen, self.bird.getX()+5, self.bird.getY()+20, self.bird.getX()+5,self.bird.getY()+40)
        else:
            self.rubberBand.draw(self.screen, 170, 500, 180, 500)

        # Since double buffering is used, the flip method
        # switches the displayed buffer and the drawing buffer.
        pygame.display.flip()

    def on_cleanup(self):
        pygame.quit()

    def on_execute(self):
        if not self.on_init():
            self._running = False

        while( self.running ):
            for event in pygame.event.get():
                self.on_event(event)
            self.on_loop()
            self.on_render()
        self.on_cleanup()

if __name__ == "__main__" :
    theApp = App()
    theApp.on_execute()
